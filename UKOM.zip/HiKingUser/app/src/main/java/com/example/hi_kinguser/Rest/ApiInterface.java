package com.example.hi_kinguser.Rest;

import com.example.hi_kinguser.Model.GetBarang;
import com.example.hi_kinguser.Model.ModelBarang;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.PUT;

public interface ApiInterface {

        @GET("api/barang")
        Call<List<ModelBarang>> getBarang();

//        @GET("api/order")
//        Call<GetHistory> gethistory();


}
