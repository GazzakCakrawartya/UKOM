package com.example.hi_kinguser.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelBarang {
    @SerializedName("idbarang")
    @Expose
    private Integer idbarang;
    @SerializedName("idkategori")
    @Expose
    private Integer idkategori;
    @SerializedName("namabarang")
    @Expose
    private String namabarang;

    private String deskripsibarang;

    @SerializedName("harga")
    @Expose
    private Integer harga;
    @SerializedName("jumlah")
    @Expose
    private Integer jumlah;
    @SerializedName("imgbarang")
    @Expose
    private String imgbarang;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("created_at")
    @Expose
    private Object createdAt;
    @SerializedName("updated_at")
    @Expose
    private Object updatedAt;

    public ModelBarang(Integer idbarang, Integer idkategori, String namabarang, String deskripsibarang, Integer harga, Integer jumlah, String imgbarang, Integer status, Object createdAt, Object updatedAt) {
        this.idbarang = idbarang;
        this.idkategori = idkategori;
        this.namabarang = namabarang;
        this.deskripsibarang = deskripsibarang;
        this.harga = harga;
        this.jumlah = jumlah;
        this.imgbarang = imgbarang;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Integer getIdbarang() {
        return idbarang;
    }

    public void setIdbarang(Integer idbarang) {
        this.idbarang = idbarang;
    }

    public Integer getIdkategori() {
        return idkategori;
    }

    public void setIdkategori(Integer idkategori) {
        this.idkategori = idkategori;
    }

    public String getNamabarang() {
        return namabarang;
    }

    public void setNamabarang(String namabarang) {
        this.namabarang = namabarang;
    }

    public String getDeskripsibarang() {
        return deskripsibarang;
    }

    public void setDeskripsibarang(String deskripsibarang) {
        this.deskripsibarang = deskripsibarang;
    }

    public Integer getHarga() {
        return harga;
    }

    public void setHarga(Integer harga) {
        this.harga = harga;
    }

    public Integer getJumlah() {
        return jumlah;
    }

    public void setJumlah(Integer jumlah) {
        this.jumlah = jumlah;
    }

    public String getImgbarang() {
        return imgbarang;
    }

    public void setImgbarang(String imgbarang) {
        this.imgbarang = imgbarang;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Object getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Object createdAt) {
        this.createdAt = createdAt;
    }

    public Object getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Object updatedAt) {
        this.updatedAt = updatedAt;
    }

}



