package com.example.hi_kinguser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hi_kinguser.Login.LoginRequest;
import com.example.hi_kinguser.Login.LoginResponse;
import com.example.hi_kinguser.Rest.ApiClient;
import com.example.hi_kinguser.Service.BarangService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    EditText username,password;
    Button btnlogin,btnlupapassword;
    BarangService barangService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.edtLoginUsername);
        password = findViewById(R.id.edtLoginPassword);
        btnlogin = findViewById(R.id.button10);
        btnlupapassword = findViewById(R.id.button9);
        barangService = ApiClient.getClient().create(BarangService.class);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(username.getText().toString())){
                    username.setError("Username harus diisi");
                    username.requestFocus();
                }else if (TextUtils.isEmpty(password.getText().toString())){
                    password.setError("Password harus diisi");
                    password.requestFocus();
                }else{
                    login();
                }
            }
        });

    }

    public void login(){
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(username.getText().toString());
        loginRequest.setPassword(password.getText().toString());
        Call<LoginResponse> call = barangService.loginUser(loginRequest);
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.body() == null){
                    Toast.makeText(LoginActivity.this, "Username/password salah", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }

            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Username/password salah", Toast.LENGTH_SHORT).show();
                Log.e("Retrofit", t.toString());

            }
        } );
    }


    public void lupapass(View view) {
        Intent intent = new Intent(LoginActivity.this, LupaPassword.class);
        startActivity(intent);
    }
}