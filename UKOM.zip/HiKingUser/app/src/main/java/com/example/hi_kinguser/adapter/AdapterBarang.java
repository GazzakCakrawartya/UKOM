package com.example.hi_kinguser.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hi_kinguser.DetailTransactionActivity;
import com.example.hi_kinguser.Model.ModelBarang;
import com.example.hi_kinguser.R;

import java.util.List;

public class AdapterBarang extends RecyclerView.Adapter<AdapterBarang.ViewHolder> {

   private Context context;
  private List<ModelBarang> data;

    public AdapterBarang(Context context, List<ModelBarang> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ModelBarang barang = data.get(position);
        holder.tvbarang.setText(data.get(position).getNamabarang());
        holder.tvharga.setText(String.valueOf(data.get(position).getHarga()));
        holder.tvdeskripsi.setText(data.get(position).getDeskripsibarang());

        
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailTransactionActivity.class);
                intent.putExtra("namabarang",barang.getNamabarang());
                intent.putExtra("harga",barang.getHarga());
                intent.putExtra("deskripsibarang",barang.getDeskripsibarang());
                intent.putExtra("imgbarang",barang.getImgbarang());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvdeskripsi,tvbarang,tvharga;
        CardView cv;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvdeskripsi = itemView.findViewById(R.id.textView10);
            tvbarang = itemView.findViewById(R.id.textView5);
            tvharga = itemView.findViewById(R.id.textView7);
            cv = itemView.findViewById(R.id.cardView2);
        }
    }
}
