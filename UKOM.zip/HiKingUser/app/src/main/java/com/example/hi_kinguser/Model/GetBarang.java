package com.example.hi_kinguser.Model;

import com.example.hi_kinguser.Item;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetBarang {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List<ModelBarang> data ;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<ModelBarang> getData() {
        return data;
    }

    public void setData(List<ModelBarang> data) {
        this.data = data;
    }
}
