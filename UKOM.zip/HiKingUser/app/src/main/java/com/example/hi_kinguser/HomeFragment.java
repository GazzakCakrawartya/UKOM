package com.example.hi_kinguser;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hi_kinguser.Model.ModelBarang;
import com.example.hi_kinguser.Rest.ApiClient;
import com.example.hi_kinguser.Rest.ApiInterface;
import com.example.hi_kinguser.adapter.AdapterBarang;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {
    RecyclerView recyclerView;
    List<ModelBarang> barangList;
    View rootView;
    ApiInterface apiInterface;
    AdapterBarang adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_home, container, false);

        load();
        isiData();
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Toolbar appbar = view.findViewById(R.id.customToolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(appbar);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(false);

        TextView tvTitle = view.findViewById(R.id.tvToolbar);
        tvTitle.setText("Home");

        ImageView ivBack = view.findViewById(R.id.btnBack);
        ivBack.setVisibility(View.GONE);


    }

//    public void load(){
//        recyclerView = rootView.findViewById(R.id.recHome);
//        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
//    }

//    public void isiData() {
//        itemList = new ArrayList<Item>();
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//        itemList.add(new Item("Tas Ransel", "Rp.25.000"));
//
//        adapter = new ItemAdapter(getActivity(),itemList);
//        recyclerView.setAdapter(adapter);
//    }

    public void load() {
        recyclerView = rootView.findViewById(R.id.recHome);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }

    public void isiData() {
        retrofit2.Call<List<ModelBarang>> barangCall = apiInterface.getBarang();
        Log.d("url", barangCall.request().url().toString());

        barangCall.enqueue(new Callback<List<ModelBarang>>() {
            @Override
            public void onResponse(Call<List<ModelBarang>> call, Response<List<ModelBarang>> response) {
//                Toast.makeText(getContext(), response.message(), Toast.LENGTH_SHORT).show();
                barangList = response.body();
                Toast.makeText(getContext(), "Jumlah data Kontak: " +
                        String.valueOf(barangList.size()), Toast.LENGTH_SHORT).show();
                Log.d("Retrofit Get", "Jumlah data Kontak: " +
                        String.valueOf(barangList.size()));
                adapter = new AdapterBarang(getActivity(), barangList);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<ModelBarang>> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());


            }
        });

    }
}