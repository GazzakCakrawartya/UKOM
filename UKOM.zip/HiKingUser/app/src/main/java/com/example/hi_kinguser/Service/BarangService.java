package com.example.hi_kinguser.Service;

import com.example.hi_kinguser.Login.LoginRequest;
import com.example.hi_kinguser.Login.LoginResponse;
import com.example.hi_kinguser.Model.ModelBarang;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface BarangService {

    @GET("api/Barang")
    Call<List<ModelBarang>> getData();

    @POST("api/Barang")
    Call<ModelBarang> setData(@Body ModelBarang barang);

    @DELETE("api/Barang/{id}")
    Call<ModelBarang> deleteData(@Path("id") String id);

    @PUT("api/Barang/{id}")
    Call<ModelBarang> updateData(@Path("id") String id, @Body ModelBarang barang);

    @POST("api/loginpelanggan")
    Call<LoginResponse> loginUser(@Body LoginRequest loginRequest);
}
