<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = Barang::all();
        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request,[
            'idkategori' => 'required | numeric',
            'namabarang' => 'required',
            'deskripsibarang' => 'required',
            'harga' => 'required | numeric',
            'jumlah' => 'required | numeric',
            'imgbarang' => 'required',
            'status' => 'required | numeric'

        ]);

        $gambar = $request->file('imgbarang')->getClientOriginalName();

        $request->file('imgbarang')->move('upload',$gambar);

        $data = [
            'idkategori' => $request->input('idkategori'),
            'namabarang' =>  $request->input('namabarang'),
            'harga' =>  $request->input('harga'),
            'jumlah' =>  $request->input('jumlah'),
            'imgbarang' => url('upload/'.$gambar) ,
            'status' =>  $request->input('status'),
            
        ];

        $barang = Barang::create($data);

        if ($barang) {
            return response()->json([
                'pesan' => 'Data sudah di simpan'
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function show(Barang $barang)
    {
        $data = DB::table('barangs')
       ->join('kategoris','kategoris.idkategori','=','barangs.idkategori')
       ->select('barangs.*','kategoris.kategori')
       ->where('idbarang','=',$id)
      
       ->get();

        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function edit(Barang $barang)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Barang $barang)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function destroy(Barang $barang)
    {
        //
    }
}
