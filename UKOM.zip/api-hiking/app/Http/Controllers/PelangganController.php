<?php

namespace App\Http\Controllers;

use App\Models\Pelanggan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PelangganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Pelanggan::all();

      return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request,[
            'username' => 'required',
            'password' => 'required ',
            'alamat' => 'required',
            'notelp' => 'required',
            // 'imgpelanggan' => 'required'

        ]);

        $data=[
            'username' => $request->input('username'),
            'password'=>Hash::make($request->input('password')),
            'alamat'=>$request->input('alamat'),
            'notelp'=>$request->input('notelp'),
            // 'imgpelanggan'=> url('upload/'.$gambar)
        ];

        $pelanggan = Pelanggan::create($data);
        if ($pelanggan) {
            return response()->json([
                'success' => true,
                'massage' => 'Register succes!',
                'data' => $pelanggan
            ], 200);
        }else{
            return response()->json([
                'succes'=>false,
                'massage'=>'Register Fail',
                'data'=>''
            ]);
        }
    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function show(Pelanggan $pelanggan)
    {
        $data = Pelanggan::where('idpelanggan',$id)->get();

        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function edit(Pelanggan $pelanggan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pelanggan $pelanggan)
    {
        //
       $pelanggan = Pelanggan::where('idpelanggan',$id)->update($request->all());

       if ($pelanggan) {
        return response()->json([
            'pesan' => 'Data sudah di update',
            'status' => 201
        ]);
       }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pelanggan $pelanggan)
    {
        //

      $pelanggan =  Pelanggan::where('idpelanggan',$id)->delete();

      if ($pelanggan) {
        return response()->json([
            'pesan' => 'data sudah di hapus',
            'data' => $pelanggan
        ]);
      }
    }

    public function login(Request $request) {
        $username = $request->input("username");
        $password = $request->input("password");

        $pelanggan = Pelanggan::where('username',$username)->first();
        if(Hash::check($password, $pelanggan->password)) {
            if($pelanggan){
                return response()->json($pelanggan);
            }else{
                return response()->json(['status'=>false]);
            }
        }
    }
}
